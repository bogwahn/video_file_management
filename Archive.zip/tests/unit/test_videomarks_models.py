from collections.abc import Iterable
from datetime import timedelta
from pathlib import Path
from typing import cast

import pytest

from video_file_management.videomarks.models import (
    Bookmark,
    BookmarksFile,
    BookmarksFileReader,
    Chapter,
    ChaptersFile,
    ChaptersFileReader,
    TimeCode,
)


@pytest.mark.parametrize(
    "value",
    [
        "1:02:03.004",
        "00:60:00.000",
        "00:00:60.000",
        "00:00:00.0000",
    ],
)
def test_timecode_rejects_noncanonical_or_out_of_range_fields(value: str) -> None:
    with pytest.raises(ValueError, match="Invalid timecode"):
        TimeCode.from_string(value)


def test_timecode_rejects_negative_timedelta() -> None:
    with pytest.raises(ValueError, match="negative"):
        TimeCode(timedelta(seconds=-0.5))


def test_bookmarks_file_rejects_chapter_in_constructor() -> None:
    marks = cast(Iterable[Bookmark], [Chapter(TimeCode(), "Opening")])

    with pytest.raises(TypeError, match="Bookmark"):
        BookmarksFile(marks)


def test_bookmarks_file_rejects_chapter_when_added() -> None:
    bookmarks = BookmarksFile()

    with pytest.raises(TypeError, match="Bookmark"):
        bookmarks.addMark(Chapter(TimeCode(), "Opening"))


def test_chapters_file_rejects_bookmark_in_constructor() -> None:
    marks = cast(Iterable[Chapter], [Bookmark(TimeCode(), "Opening")])

    with pytest.raises(TypeError, match="Chapter"):
        ChaptersFile(marks)


def test_chapters_file_rejects_bookmark_when_added() -> None:
    chapters = ChaptersFile()

    with pytest.raises(TypeError, match="Chapter"):
        chapters.addMark(Bookmark(TimeCode(), "Opening"))


@pytest.mark.parametrize(
    ("reader_type", "line"),
    [
        (BookmarksFileReader, "00:00:01.000,"),
        (ChaptersFileReader, "[00:00:01.000] "),
    ],
)
def test_mark_readers_reject_empty_labels_with_line_number(
    tmp_path: Path,
    reader_type: type[BookmarksFileReader] | type[ChaptersFileReader],
    line: str,
) -> None:
    file_path = tmp_path / "marks.txt"
    file_path.write_text(f"{line}\n", encoding="utf-8")

    with pytest.raises(ValueError, match="line 1"):
        reader_type(str(file_path)).read()
